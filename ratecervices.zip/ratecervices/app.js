const emojis = document.querySelectorAll('.emoji');
const selectedRating = document.getElementById('selected-rating');
const modalEmoji = document.getElementById('modalEmoji');
const modal = document.getElementById('thankYouModal');
const webAppUrl = 'https://script.google.com/macros/s/AKfycbxTq4-jSA-6dvXNfFe_gO68GcmkANzU4k7Kj5N1J1uUeyHQr7VzA1SAS3E8ZnH5xi0/exec'; // Replace with your web app URL
let currentRating = null;

// Event listener for emoji selection
emojis.forEach(emoji => {
    emoji.addEventListener('click', () => {
        emojis.forEach(e => e.classList.remove('selected'));
        emoji.classList.add('selected');
        currentRating = emoji.getAttribute('data-rating');
        selectedRating.textContent = currentRating;
    });
});

// Event listener for "Send Rating" button
document.getElementById('sendRatingButton').addEventListener('click', () => {
    const hallSelect = document.getElementById('hallSelect');
    const selectedHall = hallSelect.value;

    if (currentRating && selectedHall) {
        const emojiMap = {
            '1': '😡',
            '2': '😟',
            '3': '😐',
            '4': '🙂',
            '5': '😍'
        };

        modalEmoji.textContent = emojiMap[currentRating] || '🙂';
        modal.style.display = 'flex';  // Show the modal

        // Send data to Google Sheets
        fetch(webAppUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams({
                'rating': currentRating,
                'hall': selectedHall
            })
        })
        .then(response => response.text())
        .then(data => {
            console.log('Success:', data);
            // Close the modal after 2 seconds
            setTimeout(() => {
                modal.style.display = 'none';
                currentRating = null;
                selectedRating.textContent = 'None';
                emojis.forEach(e => e.classList.remove('selected'));
            }, 2000);
        })
        .catch(error => {
            console.error('Error:', error);
        });
    } else {
        alert('Please select a rating and hall first!');
    }
});

// Close modal if clicking outside of it
window.addEventListener('click', event => {
    if (event.target === modal) {
        modal.style.display = 'none';
    }
});
